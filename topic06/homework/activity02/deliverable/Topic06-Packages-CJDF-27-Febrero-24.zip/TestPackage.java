import MyUtilities.math.Operations;

public class TestPackage {
    public static void main(String args[]) {
        Operations operations = new Operations();
        System.out.println("result = " + operations.add(3, 5));
    }
}